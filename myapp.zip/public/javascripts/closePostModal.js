function closePostModal(){
	$('#postModal').modal('hide');
}