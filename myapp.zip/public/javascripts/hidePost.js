function hidePost(postId) {
	document.getElementById(postId).style.display = 'none'
}
