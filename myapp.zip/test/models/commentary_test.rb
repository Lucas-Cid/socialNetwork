require 'test_helper'

class CommentaryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
